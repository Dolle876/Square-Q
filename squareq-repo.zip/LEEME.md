# Square-Q · cómo subir y probar

## 1. Subir
Subí **todo el contenido de esta carpeta** a la raíz de tu repositorio (incluida la carpeta oculta `.github`).
En GitHub: Settings → Pages → "Deploy from a branch" → rama `main`, carpeta `/ (root)`.

## 2. Probar las carpetas pre-cargadas del Entrenador
1. Abrí la página → Entrenador de algoritmos → bajá hasta el final.
2. Tiene que aparecer **"⭐ Carpetas pre-cargadas"** con una carpeta de prueba ("PRUEBA (borrar)") y el botón "Agregar a mis carpetas".
3. Para poner las tuyas: armalas en tu Entrenador → "Descargar todo" → renombrá el archivo a `precargadas.json` y reemplazá el de la carpeta.
   (Va todo lo que tengas en tu app: dejá solo las carpetas que quieras compartir.)
4. Si dice "No se pudieron cargar", la página se abrió como archivo local o `precargadas.json` no está en la misma carpeta que `index.html`.

## 3. Probar las mezclas de TNoodle
1. En GitHub: pestaña **Actions** → "Generar mezclas TNoodle" → **Run workflow**.
2. Cuando termine (2–5 min), el repo tiene una carpeta `scrambles/` con archivos como `333.json`.
   Si en el log de la ejecución ves líneas **FALLO**, copiámelas.
3. En la página: Timer → una categoría. Debajo del título dice:
   - `Mezclas: TNoodle · 1000 disponibles (scrambles/333.json)` → funciona.
   - `Mezclas: no se encontró ... → se usan mezclas locales (no oficiales)` → todavía no hay archivo.
4. Dentro del timer, sobre el tiempo aparece "Mezcla oficial (TNoodle)" cuando viene del pool.

## 4. Modo sin conexión
En la página principal: "Guardar para usar sin conexión" (hacelo con internet y después de generar las mezclas).
